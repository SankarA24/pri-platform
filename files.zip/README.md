# PRI Platform — Prompt Intelligence & Career Intelligence System

> A full-stack AI platform combining **Prompt Engineering training** with a **5-Agent Career Employability Analyzer** backed by IEEE research.

Built as part of M.Tech CSE research at Sri Krishna College of Engineering and Technology.

---

## 🚀 Live Features

### ⚡ Prompt Intelligence (PRI)
- 4 real-world web dev challenges (Responsive Layouts, API Integration, React State, CSS Architecture)
- AI evaluates your prompt across 5 dimensions: Clarity, Constraints, Output Spec, Edge Cases, Precision
- Glitched code injection — detect bugs in AI-generated code
- PRI Score (0–100) combining prompt quality + bug detection + reasoning depth
- Full history and per-challenge performance breakdown

### 🎯 Career Intelligence System
- 7-phase deep interview chatbot — collects academic, skills, internship, project, and career goal data
- **5-Agent Pipeline** powered by Groq (LLaMA 3.3 70B):
  - **Agent 1 — Extractor**: Parses chat + resume + GitHub + LeetCode into structured profile
  - **Agent 2 — Scorer**: Applies IEEE research weights (Internship ×0.45, Skills ×0.25, Academic ×0.20, Activities ×0.10)
  - **Agent 3 — Gap Analyzer**: Compares profile vs role requirements database
  - **Agent 4 — Resume Ranker**: ATS score, section scores, missing keywords, improvements
  - **Agent 5 — Roadmap Builder**: Personalized 3-phase action plan with real resource links
- Resume upload (PDF) → Cloudinary → AI text extraction → ranking
- GitHub API integration → repos, languages, stars auto-fetched
- LeetCode API integration → solved count by difficulty
- Resume generation from chat if no resume uploaded → download as HTML/PDF
- Floating chatbot after analysis for quick updates

### 🛡️ Auth & Roles
- JWT-based email/password auth
- Student vs Admin roles
- Protected routes, persistent sessions

### 📊 Admin Dashboard
- All registered students with latest scores
- Aggregate analytics: avg score by role, readiness distribution
- Score distribution charts
- Export students to CSV

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, React Router |
| Backend | Node.js, Express.js |
| AI / LLM | Groq API (LLaMA 3.3 70B) |
| Database | PostgreSQL |
| Auth | JWT (jsonwebtoken + bcryptjs) |
| File Storage | Cloudinary |
| External APIs | GitHub REST API, LeetCode GraphQL API |
| Styling | Pure CSS-in-JS (no UI library) |

---

## 📁 Project Structure

```
pri-platform/
├── backend/
│   ├── index.js          # All API routes (PRI + Career + Auth + Admin)
│   ├── db.js             # PostgreSQL connection pool
│   ├── authMiddleware.js # JWT middleware
│   └── schema.sql        # Full database schema
└── frontend/
    └── src/
        ├── pages/
        │   ├── AuthPage.jsx         # Login / Register
        │   ├── ChallengePage.jsx    # PRI challenges
        │   ├── CareerPage.jsx       # Career intelligence chat + results
        │   ├── AdminPage.jsx        # Admin analytics dashboard
        │   ├── HistoryPage.jsx      # Challenge attempt history
        │   └── GlitchStatsPage.jsx  # Prompt quality breakdown
        ├── components/
        │   ├── Layout.jsx           # Sidebar + topbar
        │   └── ProfileSetupPanel.jsx # GitHub/LeetCode/Resume upload
        └── context/
            └── AuthContext.jsx      # Global auth state
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Node.js 18+
- PostgreSQL 15+
- Groq API key (free at [console.groq.com](https://console.groq.com))
- Cloudinary account (free at [cloudinary.com](https://cloudinary.com))

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/pri-platform.git
cd pri-platform
```

### 2. Set up the database
```bash
psql -U postgres
CREATE DATABASE pri_platform;
\c pri_platform
\i backend/schema.sql
\q
```

### 3. Configure environment
Create `backend/.env`:
```env
GROQ_API_KEY=your_groq_key
PORT=3001
NODE_ENV=development
JWT_SECRET=your_secret_key
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/pri_platform
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

### 4. Install dependencies
```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

### 5. Run the platform
```bash
# Terminal 1 — Backend
cd backend && npm run dev

# Terminal 2 — Frontend
cd frontend && npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

### 6. Create admin account
```bash
curl -X POST http://localhost:3001/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Admin","email":"admin@pri.dev","password":"yourpassword"}'

# Then set admin role in psql:
# UPDATE users SET role='admin' WHERE email='admin@pri.dev';
```

---

## 📚 Research Basis

The scoring system is based on:

> **Saidani et al. (2022)** — "Predicting Student Employability Through Applied Learning Intelligence" — *IEEE Access*, Vol. 9

Scoring weights derived from the paper:
- Internship experience: **45%** (highest employability predictor)
- Technical skills: **25%**
- Academic performance: **20%**
- Co-curricular activities: **10%**

---

## 👥 Team

| Name | Roll No | Role |
|---|---|---|
| Vikash SK | 727722EUCI057 | Frontend & Dashboard Engineer |
| Sankar A | 727722EUCI040 | ML Engineer & Data Pipeline Lead |
| Shaffan Ahmed F | 727722EUCI042 | Backend & Database Engineer |

**Mentor:** Mr. Sreeraj S, Assistant Professor, Dept. of M.Tech CSE  
**Institution:** Sri Krishna College of Engineering and Technology, Coimbatore

---

## 📄 License

MIT License — free to use, modify, and distribute.
